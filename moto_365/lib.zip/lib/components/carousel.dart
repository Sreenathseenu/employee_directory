import 'package:flutter/material.dart';

class Carousel extends StatelessWidget {
  Carousel({this.pageController, this.images, this.height});

  final PageController pageController;
  final List images;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
        height: height,
        child: PageView.builder(
      controller: pageController,
      itemCount: images.length,
      itemBuilder: (BuildContext context, int index) {
        return  AnimatedBuilder(
           animation: pageController,
      builder: (BuildContext context, Widget widget){
        double value=1;
        if (pageController.position.haveDimensions){
          value=pageController.page-index;
          value=(1-(value.abs()*0.15)).clamp(0.0, 1.0);
        }
        return Center(child:SizedBox(height:Curves.easeIn.transform(value)*height,child:widget),);
      },
                  child: Container(
            margin: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color:Colors.transparent,
              borderRadius: BorderRadius.circular(10)
            ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                                child: Image(
            image: NetworkImage(images[index]['image']),
            //AssetImage('assets/images/slice.png'),
            fit: BoxFit.cover,
          ),
              )),
        );
      }),
      );
  }
}
/*PageController _pageController;

  @override
  void initState() {
    
    super.initState();
    _pageController=PageController(initialPage: 0, viewportFraction: 0.8);
  }*/