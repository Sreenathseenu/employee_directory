import 'package:flutter/foundation.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:moto_365/models/urls.dart';

class Services with ChangeNotifier {
  List<dynamic> _items = [];
  List itemSearch = [];
  List serviceGroup = [];
  List images = [];
  List groupServices = [];
  // String image = '';
  final String _token;
  bool isLoading = true;

  Services(this._token) {
    fetchServices();
  }

  get items {
    return [..._items];
  }

  Future<void> fetchServices() async {
    try {
      final url = '${Url.domain}/service/';
      final response = await http.get(url, headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        //'Authorization': 'Bearer $_token'
      });
      _items = json.decode(response.body) as List;
      isLoading = false;
      // print(_items[0]['id']);
      print('services');
      notifyListeners();
    } catch (error) {
      print(error);
    }
  }

  Future<void> fetchServicesSearch(query) async {
    try {
      // final url = '${Url.domain}/service/?search=cleaning';

      final response =
          await http.get('${Url.domain}/service/?search=$query', headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        //'Authorization': 'Bearer $_token'
      });
      itemSearch = json.decode(response.body) as List;
      isLoading = false;
      // print(_items[0]['id']);
      print('services');
      notifyListeners();
    } catch (error) {
      print(error);
    }
  }

  Future<void> fetchServicesGroup() async {
    try {
      final url = '${Url.domain}/servicegroup/';
      final response = await http.get(url, headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        //'Authorization': 'Bearer $_token'
      });
      serviceGroup = json.decode(response.body) as List;
      fetchServices();
      isLoading = false;
      // print(_items[0]['id']);
      print('services');
      notifyListeners();
    } catch (error) {
      print(error);
    }
  }

  void getGroupServ(id) {
    isLoading = true;
    groupServices.clear();
    notifyListeners();
    for (int i = 0; i < _items.length; i++) {
      for (int j = 0; j < _items[i]["service_group"].length; j++) {
        if (_items[i]["service_group"][j]['id'] == id) {
          groupServices.add(_items[i]);
        } else {
          continue;
        }
      }
    }
    //isLoading = false;
    // print(_items[0]['id']);
    isLoading = false;
    print('image');
    notifyListeners();
  }

  String getImages(id) {
    String image;
    for (int i = 0; i < images.length; i++) {
      if (images[i]['id'] == id) {
        image = images[i]['image'];
        break;
      } else {
        continue;
      }
    }
    //isLoading = false;
    // print(_items[0]['id']);
    print('image');
    notifyListeners();
    return image;
  }

  Future<void> fetchImages() async {
    try {
      final url = '${Url.domain}/document/';
      final response = await http.get(url, headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        //'Authorization': 'Bearer $_token'
      });
      images = json.decode(response.body) as List;

      //isLoading = false;
      // print(_items[0]['id']);
      print('image');
      notifyListeners();
    } catch (error) {
      print(error);
    }
  }
}
