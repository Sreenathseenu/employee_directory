import 'dart:convert';
import 'package:intl/intl.dart';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:moto_365/models/urls.dart';

class Cart with ChangeNotifier {
  List _items = [];
  List orders = [];
  final String _token;
  List<dynamic> services = [];
  List<dynamic> products = [];
  List<dynamic> all = [];
  bool isLodaing = true;
  String text;
  bool isLodaingOrders = true;
  Cart(this._token) {
    fetchCart();
    //fetchOrders();
  }
  get items {
    return [..._items];
  }

  Future<void> fetchCart() async {
    try {
      final url = '${Url.domain}/cart/';
      final response = await http.get(url, headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_token'
      });
      //print(response.body);
      _items = json.decode(response.body);
      products = _items[0]['product'];
      services = _items[0]['service'];
      all = [...products, ...services];
      print("cart");
      isLodaing = false;
      notifyListeners();
    } catch (error) {
      print(error);
    }
  }

  Future<void> clearCart() async {
    try {
      final id = _items[0]['id'];
      // final url = '${Url.domain}/cart/$id/';
      final response = await http
          .delete('${Url.domain}/cart/$id/', headers: {
        'Content-type': 'application/json',
        'Authorization': 'Bearer $_token'
      });
      print(response.body);

      notifyListeners();
    } catch (error) {
      print('error');
    }
  }

  Future<void> addToCart(int id, int quantity, String mode) async {
    try {
      final url = '${Url.domain}/cart/add_to_cart/';
      final response = mode == 'service'
          ? await http.post(url,
              headers: {
                'Content-type': 'application/json',
                'Authorization': 'Bearer $_token'
              },
              body: json.encode({
                'service': [
                  {'service': id}
                ]
              }))
          : await http.post(url,
              headers: {
                'Content-type': 'application/json',
                'Authorization': 'Bearer $_token'
              },
              body: json.encode({
                'product': [
                  {'product': id, 'quantity': quantity}
                ]
              }));
      // print(response.body);
      print(response.statusCode);
      notifyListeners();
    } catch (error) {
      print(error);
    }
  }

  Future<void> addProductQuantity(id) async {}

  Future<void> placeOrder() async {
    try {
      final url = '${Url.domain}/order/place_orders/';
      final response = await http.post(url, headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_token'
      });
      print(response.statusCode);

      notifyListeners();
    } catch (error) {
      print('error');
    }
  }

  Future<void> fetchOrders() async {
    try {
      final url = '${Url.domain}/order';
      final response = await http.get(url, headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_token'
      });
      //print(response.body);
      orders = json.decode(response.body);
      // products=_items[0]['product'];
      // services=_items[0]['service'];
      print("orders");
      if (orders != null || orders != []) {
        if (orders[0]["status"] == 1) {
          text = 'pending';
        } else if (orders[0]["status"] == 2) {
          text = 'accepted';
        } else if (orders[0]["status"] == 3) {
          text = 'processing';
        } else if (orders[0]["status"] == 4) {
          text = 'finished';
        } else if (orders[0]["status"] == 5) {
          text = 'delivered';
        }
      }
      isLodaingOrders = false;
      notifyListeners();
    } catch (error) {
      print('orders error: $error');
    }
  }
}
