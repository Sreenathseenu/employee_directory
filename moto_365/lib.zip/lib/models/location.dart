class Location{
  final double latitude;
  final double longitude;
  final String address;

  Location({this.address,this.latitude,this.longitude});
}