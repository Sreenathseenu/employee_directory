



/*class Customer{
  final int id;
  final int address;
  final int userId;
  final String username;
  final String email;
  final String photo;
  final double latitude;
  final double longitude;
  final int customerVehicle;
  final String name;
  final int age;
  final String gender;
  final String phone;
  final String dob;

  Customer({this.id, this.address, this.userId, this.username, this.email, this.photo, this.latitude, this.longitude, this.customerVehicle, this.name, this.age, this.gender, this.phone, this.dob});




}*/

/*
 "id": 6,
        "address": {
            "id": 2,
            "address_line1": "fghkfkhfuj",
            "address_line2": "fgxdfgdhg",
            "address_line3": "trytrutyrutyrty",
            "state": "kerala",
            "district": "hjhj",
            "city": "hjgkjh",
            "pin_code": "670307"
        },
        "user": {
            "id": 7,
            "last_login": null,
            "email": "bb@gmail.com",
            "first_name": "rbamu",
            "last_name": "fp",
            "username": "wer",
            "phone": "+917808907678",
            "date_joined": "2020-05-26T15:02:56.820000Z",
            "groups": [],
            "user_permissions": []
        },
        "photo": {
            "id": 1,
            "image": "https://automoto.techbyheart.in/media/image/wallpapersden.com_sony-electric-car_1920x1080.jpg"
        },
        "location": {
            "latitude": -98.677068,
            "longitude": 23.0625
        },
        "vehicle": {
            "id": 1,
            "model_year": 2016,
            "chassis_no": "134232",
            "engine_no": "13",
            "is_active": true,
            "rc_book": 1,
            "vehicle": 1
        },
        "name": "dsa",
        "age": 21,
        "gender": "male",
        "phone": "+917808907678",
        "dob": null
    },
*/