class Url {
  static const domain = "https://automoto.techbyheart.in/api/v1";
   static const main = "https://automoto.techbyheart.in";
  //static const main = "http://95.217.232.85:8080";
  //static const domain = "http://95.217.232.85:8080/api/v1";
  /*static const main = "http://192.168.1.110:8000/";
  static const domain = "http://192.168.1.110:8000/api/v1";*/
}
