
/*class Service{
  final int id;
 final List<int> vehicles;
  final List<int> products;
  final List<int> images;
  final List<int> groups;
  final String name;
  final String currency;
  final double price;
  final int stock;
  final String description;
  final String instructions;
  final String sgstCurrency;
  final String cgsttCurrency;
  final String igstCurrency;
  final double sgst;
  final double cgst;
  final double igst;


  Service({this.vehicles, this.products, this.groups, this.currency, this.price, this.stock, this.description, this.instructions, this.sgstCurrency, this.cgsttCurrency, this.igstCurrency, this.sgst, this.cgst, this.igst, this.id, this.images, this.name});
  
  
  
  



}*/

    /*   {
        "id": 1,
        "vehicles": [
            {
                "id": 1,
                "brand": "bmw",
                "fuel": "PETROL",
                "model": "x5",
                "logo": 1
            }
        ],
        "product": [
            {
                "id": 1,
                "is_available": true,
                "image": [
                    {
                        "id": 1,
                        "image": "https://automoto.techbyheart.in/media/image/wallpapersden.com_sony-electric-car_1920x1080.jpg"
                    }
                ],
                "code": "23",
                "product": "powder",
                "mfg_date": "2020-01-01",
                "expiry_date": "2020-10-10",
                "price_currency": "INR",
                "price": "60.00",
                "stock_count": 10,
                "is_accessory": false,
                "is_saleable": false,
                "is_for_service": true,
                "is_available_online": false,
                "gst": 1,
                "vendor": 1
            }
        ],
        "images": [
            {
                "id": 3,
                "image": "https://automoto.techbyheart.in/media/image/image_picker2073997382.jpg"
            }
        ],
        "service_group": [],
        "name": "errr",
        "price_currency": "INR",
        "price": "45.00",
        "time": "15:46:21.218000",
        "description": "hghjhgj",
        "instruction": "http://abcd.com",
        "sgst_currency": "INR",
        "sgst": "56.00",
        "cgst_currency": "INR",
        "cgst": "56.00",
        "igst_currency": "INR",
        "igst": "65.00"
    }
    },*/