/*abstract class Products{
  final int id;
  final bool isAvailable;
  final List<int> images;
  final String code;
  final String name;
  final String mfg;
  final String exp;
  final String currency;
  final double price;
  final int stock;
  final int gst;
  final int vendor;

  Products({this.isAvailable, this.images, this.code, this.name, this.mfg, this.exp, this.currency, this.price, this.stock, this.gst, this.vendor, this.id});


}*/

/*
{
        "id": 1,
        "is_available": true,
        "image": [
            {
                "id": 1,
                "image": "https://automoto.techbyheart.in/media/image/wallpapersden.com_sony-electric-car_1920x1080.jpg"
            }
        ],
        "code": "23",
        "product": "powder",
        "mfg_date": "2020-01-01",
        "expiry_date": "2020-10-10",
        "price_currency": "INR",
        "price": "60.00",
        "stock_count": 10,
        "is_accessory": false,
        "is_saleable": false,
        "is_for_service": true,
        "is_available_online": false,
        "gst": 1,
        "vendor": 1
    }
*/