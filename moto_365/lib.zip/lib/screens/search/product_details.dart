import 'package:flutter/material.dart';
import 'package:moto_365/components/button.dart';
import 'package:moto_365/components/carousel.dart';
import 'package:moto_365/components/gard.dart';
import 'package:moto_365/providers/auth_provider.dart';
import 'package:moto_365/providers/cart_provider.dart';
import 'package:moto_365/screens/auth/login_screen.dart';
import 'package:provider/provider.dart';

class ProductDetails extends StatefulWidget {
  final Map item;
  ProductDetails(this.item);

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  PageController _pageController;

  @override
  void initState() {
    
    super.initState();
    _pageController=PageController(initialPage: 0, viewportFraction: 0.8);
  }
  @override
  Widget build(BuildContext context) {
    final data = Provider.of<Cart>(context);
    final adata = Provider.of<Auth>(context);
    return Scaffold(
        body: ListView(
         // mainAxisAlignment:MainAxisAlignment.spaceEvenly,
    children: <Widget>[
      Carousel(pageController: _pageController,images: widget.item['image'],height: 200, ),
      SizedBox(height:20),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal:16.0),
        child: Text(widget.item['product'],
            style: TextStyle(
                fontSize: 24,
                color: Colors.white70,
                fontFamily: 'Montserrat')),
      ),
              SizedBox(height:10),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal:16.0),
                 child: Text(widget.item['description'],
    style:TextStyle(
       fontSize: 12,
      color:Colors.white,
      fontFamily: 'Montserrat'
    )
    ),
               ),SizedBox(height:20),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal:16.0),
        child: Text('stock : ${widget.item['stock_count']}',
            style: TextStyle(
                fontSize: 12, color: Colors.white, fontFamily: 'Montserrat')),
      ),
              SizedBox(height:20),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal:16.0),
        child: Text('price : Rs ${widget.item['price']}',
            style: TextStyle(
                fontSize: 12,
                color: Colors.yellow,
                fontFamily: 'Montserrat')),
      ),
              SizedBox(height:20),
      Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal:16.0),
          child: Button(
            onPress: () {
              if(adata.isAuth){              data.addToCart(widget.item['id'], 1,'products').then((value) {
                Scaffold.of(context).hideCurrentSnackBar();
                Scaffold.of(context).showSnackBar(SnackBar(
                  content: Text('successfully added to cart',
                      style: TextStyle(color: Colors.white)),
                  duration: Duration(seconds: 3),
                  backgroundColor: Colors.grey[900],
                ));
              });}else{
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>LoginScreen()));
              }
            },
            text: 'ADD TO CART',
          ),
        ),
      ),
      SizedBox(height:20),
    ],
        ),
      );
  }
}
