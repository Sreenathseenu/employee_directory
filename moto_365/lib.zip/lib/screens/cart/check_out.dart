import 'package:flutter/material.dart';
import 'package:moto_365/components/button.dart';
import 'package:moto_365/components/gard.dart';
import 'package:moto_365/providers/auth_provider.dart';
import 'package:moto_365/providers/cart_provider.dart';
import 'package:moto_365/screens/cart/payment.dart';
import 'package:provider/provider.dart';

class CheckOut extends StatefulWidget {
  static const routeName = '/estimate';
  const CheckOut({Key key}) : super(key: key);

  @override
  _CheckOutState createState() => _CheckOutState();
}

class _CheckOutState extends State<CheckOut> {
  bool _isLoading = false;
  @override
  Widget build(BuildContext context) {
    final data = Provider.of<Cart>(context);
    //final auth = Provider.of<Auth>(context);
    return Grad(
      child: Scaffold(
        appBar: AppBar(
          title: Text('CHECKOUT'),
        ),
        body:  Column(
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                    decoration: BoxDecoration(
                        color: Colors.grey[800],
                        borderRadius: BorderRadius.circular(8)),
                    child:_isLoading
            ? Center(child: CircularProgressIndicator())
            : Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            data.services == null || data.services.isEmpty
                                ? Container(
                                    height: 0,
                                  )
                                : Column(
                                    children: data.services
                                        .map((items) => Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(items['service']['name'],
                                                    style: TextStyle(
                                                        fontFamily:
                                                            'Montserrat',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontSize: 14,
                                                        color: Colors.white70)),
                                                Text(
                                                    'Rs ${items['total_amount']}',
                                                    style: TextStyle(
                                                        fontFamily:
                                                            'Montserrat',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontSize: 14,
                                                        color: Colors.white70)),
                                              ],
                                            ))
                                        .toList()),
                            data.products == null || data.products.isEmpty
                                ? Container(
                                    height: 0,
                                  )
                                : Column(
                                    children: data.products
                                        .map((items) => Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                    items['product']['product'],
                                                    style: TextStyle(
                                                        fontFamily:
                                                            'Montserrat',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontSize: 14,
                                                        color: Colors.white70)),
                                                Text(
                                                    'Rs ${items['total_amount']}',
                                                    style: TextStyle(
                                                        fontFamily:
                                                            'Montserrat',
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontSize: 14,
                                                        color: Colors.white70)),
                                              ],
                                            ))
                                        .toList()),
                            SizedBox(height: 8),
                            Container(
                              color: Colors.white60,
                              height: 1,
                              width: double.infinity,
                            ),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text('Total',
                                    style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontWeight: FontWeight.w900,
                                        fontSize: 24,
                                        color: Colors.deepOrange)),
                                Text('Rs ${data.items[0]['amount']}',
                                    style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontWeight: FontWeight.w900,
                                        fontSize: 24,
                                        color: Colors.deepOrange)),
                              ],
                            )
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: Button(
                      onPress: () {
                        Navigator.of(context)
                              .push(MaterialPageRoute(builder: (context)=> MySample()));
                       /* data.placeOrder().then((_) {
                          
                          /* Provider.of<Cart>(context)
                              .fetchCart()
                              .then((value) => Navigator.of(context).pop());*/
                        });
                        setState(() {
                          _isLoading = true;
                        });*/
                      },
                      text: 'CHECKOUT',
                    ),
                  )
                ],
              ),
      ),
    );
  }
}
