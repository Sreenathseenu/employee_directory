import 'package:flutter/material.dart';

class LoyaltyPoint extends StatelessWidget {
  LoyaltyPoint({Key key}) : super(key: key);

 
  @override
  Widget build(BuildContext context) {
    return  Container(
              margin: EdgeInsets.only(right: 4),
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.black54,
                    offset: Offset(0.0, 1.5),
                    blurRadius: 1.5,
                  )
                ],
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(
                  
                    colors: [Color(0xFFF05C2D), Color(0xFFFCAA2E)]),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Reward Points\nearned',
                        style: TextStyle(
                            fontSize: 10,
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w900,
                            color: Colors.white)),
                    Text('1,375',
                        style: TextStyle(
                            fontSize: 48,
                            fontFamily: 'MontserratBlack',
                            fontWeight: FontWeight.w900,
                            color: Colors.black87)),
                    Text('Redeem points now!',
                        style: TextStyle(
                            fontSize: 10,
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w900,
                            color: Colors.white))
                  ],
                ),
              ),
            );
  }
}